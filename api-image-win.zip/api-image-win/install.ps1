[CmdletBinding()]
param(
  [string]$BaseUrl,
  [SecureString]$ApiKey,
  [string]$CodexHome = $env:CODEX_HOME,
  [ValidateSet("User", "Process")]
  [string]$EnvironmentTarget = "User"
)

$ErrorActionPreference = "Stop"

function Read-RelayBaseUrl {
  while ($true) {
    $candidate = (Read-Host "[1/2] Relay base URL (include /v1 if required)").Trim().TrimEnd("/")
    $parsed = $null
    if (
      [Uri]::TryCreate($candidate, [UriKind]::Absolute, [ref]$parsed) -and
      ($parsed.Scheme -eq "http" -or $parsed.Scheme -eq "https")
    ) {
      return $candidate
    }
    Write-Warning "Enter an absolute HTTP or HTTPS URL, for example https://relay.example.com/v1"
  }
}

function Read-RelayApiKey {
  while ($true) {
    $secureValue = Read-Host "[2/2] Relay API key (input is hidden)" -AsSecureString
    if ($secureValue.Length -gt 0) {
      return $secureValue
    }
    Write-Warning "API key cannot be empty"
  }
}

function ConvertFrom-SecureValue {
  param([Parameter(Mandatory = $true)][SecureString]$Value)

  $pointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($Value)
  try {
    return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer)
  } finally {
    [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer)
  }
}

if ([string]::IsNullOrWhiteSpace($BaseUrl)) {
  $BaseUrl = Read-RelayBaseUrl
} else {
  $BaseUrl = $BaseUrl.Trim().TrimEnd("/")
  $parsed = $null
  if (
    -not [Uri]::TryCreate($BaseUrl, [UriKind]::Absolute, [ref]$parsed) -or
    ($parsed.Scheme -ne "http" -and $parsed.Scheme -ne "https")
  ) {
    throw "BaseUrl must be an absolute HTTP or HTTPS URL"
  }
}

if ($null -eq $ApiKey -or $ApiKey.Length -eq 0) {
  $ApiKey = Read-RelayApiKey
}

$plainApiKey = (ConvertFrom-SecureValue -Value $ApiKey).Trim()
if ([string]::IsNullOrWhiteSpace($plainApiKey)) {
  throw "API key cannot be empty"
}

if ([string]::IsNullOrWhiteSpace($CodexHome)) {
  $CodexHome = Join-Path $HOME ".codex"
}

$source = [IO.Path]::GetFullPath($PSScriptRoot).TrimEnd("\", "/")
$target = [IO.Path]::GetFullPath((Join-Path $CodexHome "skills\api-image")).TrimEnd("\", "/")

if (-not $source.Equals($target, [StringComparison]::OrdinalIgnoreCase)) {
  New-Item -ItemType Directory -Force -Path $target | Out-Null
  New-Item -ItemType Directory -Force -Path (Join-Path $target "agents") | Out-Null
  New-Item -ItemType Directory -Force -Path (Join-Path $target "scripts") | Out-Null

  $files = @(
    "SKILL.md",
    "install.ps1",
    "setup.cmd",
    "agents\openai.yaml",
    "scripts\image_relay.mjs"
  )

  foreach ($relativePath in $files) {
    $sourcePath = Join-Path $source $relativePath
    if (-not (Test-Path -LiteralPath $sourcePath)) {
      throw "Package is missing required file: $relativePath"
    }
    Copy-Item -LiteralPath $sourcePath -Destination (Join-Path $target $relativePath) -Force
  }

  $manualPath = Join-Path $source "API-image部署说明书.docx"
  if (Test-Path -LiteralPath $manualPath) {
    Copy-Item -LiteralPath $manualPath -Destination (Join-Path $target "API-image部署说明书.docx") -Force
  }
}

[Environment]::SetEnvironmentVariable("CODEX_IMAGE_RELAY_BASE_URL", $BaseUrl, $EnvironmentTarget)
[Environment]::SetEnvironmentVariable("CODEX_IMAGE_RELAY_API_KEY", $plainApiKey, $EnvironmentTarget)

$configuredModel = "gpt-image-2.5-sunburst"
[Environment]::SetEnvironmentVariable("CODEX_IMAGE_RELAY_MODEL", $configuredModel, $EnvironmentTarget)

$env:CODEX_IMAGE_RELAY_BASE_URL = $BaseUrl
$env:CODEX_IMAGE_RELAY_API_KEY = $plainApiKey
$env:CODEX_IMAGE_RELAY_MODEL = $configuredModel
$plainApiKey = $null

Write-Output ""
Write-Output "API-image installed successfully."
Write-Output "Skill path: $target"
Write-Output "Relay URL: $BaseUrl"
Write-Output "Default model: $configuredModel"
if ($EnvironmentTarget -eq "User") {
  Write-Output "Restart Codex before using `$api-image."
}
