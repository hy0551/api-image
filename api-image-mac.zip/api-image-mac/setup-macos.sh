#!/usr/bin/env bash
set -euo pipefail

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "This installer must be run on macOS." >&2
  exit 1
fi

if [[ ! -x /usr/bin/security ]]; then
  echo "macOS Keychain command /usr/bin/security is unavailable." >&2
  exit 1
fi

source_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
codex_home="${CODEX_HOME:-$HOME/.codex}"
target="$codex_home/skills/api-image"

printf '[1/2] Relay base URL (include /v1 if required): '
IFS= read -r base_url
base_url="${base_url#"${base_url%%[![:space:]]*}"}"
base_url="${base_url%"${base_url##*[![:space:]]}"}"
while [[ "$base_url" == */ ]]; do
  base_url="${base_url%/}"
done

case "$base_url" in
  http://*|https://*) ;;
  *)
    echo "Enter an absolute HTTP or HTTPS URL, for example https://relay.example.com/v1" >&2
    exit 1
    ;;
esac

printf '[2/2] Relay API key (input is hidden): '
IFS= read -r -s api_key
printf '\n'
if [[ -z "$api_key" ]]; then
  echo "API key cannot be empty." >&2
  exit 1
fi

mkdir -p "$target/agents" "$target/scripts"
target_abs="$(cd "$target" && pwd -P)"

if [[ "$source_dir" != "$target_abs" ]]; then
  required_files=(
    "SKILL.md"
    "setup-macos.sh"
    "agents/openai.yaml"
    "scripts/image_relay.mjs"
  )

  for relative_path in "${required_files[@]}"; do
    if [[ ! -f "$source_dir/$relative_path" ]]; then
      echo "Package is missing required file: $relative_path" >&2
      exit 1
    fi
    cp -f "$source_dir/$relative_path" "$target/$relative_path"
  done

  if [[ -f "$source_dir/API-image部署说明书.docx" ]]; then
    cp -f "$source_dir/API-image部署说明书.docx" "$target/API-image部署说明书.docx"
  fi
fi

chmod +x "$target/setup-macos.sh"
umask 077
printf '%s\n' "$base_url" > "$codex_home/api-image-base-url"
chmod 600 "$codex_home/api-image-base-url"

account="${USER:-$(id -un)}"
/usr/bin/security add-generic-password \
  -a "$account" \
  -s "codex-api-image" \
  -w "$api_key" \
  -U >/dev/null
unset api_key

printf '\nAPI-image installed successfully.\n'
printf 'Skill path: %s\n' "$target"
printf 'Relay URL: %s\n' "$base_url"
printf 'Default model: gpt-image-2.5-sunburst\n'
printf 'Restart Codex before using $api-image.\n'

