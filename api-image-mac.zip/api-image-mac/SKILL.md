---
name: api-image
description: Generate or edit raster images through a configured company OpenAI-compatible relay API with an explicit image model. Use this for image generation or editing whenever the company relay is configured, especially when stable model selection or reproducible routing is required. Do not use the built-in image_gen tool or the relay_imagegen MCP server for this workflow.
metadata:
  short-description: Generate images through the company relay API
---

# API-image

Use the bundled `scripts/image_relay.mjs` helper for all generation and editing in this skill. The helper calls the relay HTTP API directly, saves image files locally, and prints machine-readable output.

## Deployment

For Windows, the user runs `setup.cmd`. For macOS, the user runs `bash setup-macos.sh`. Both installers ask for the relay base URL first and a hidden API key second, install the Skill, select `gpt-image-2.5-sunburst`, and require a Codex restart. Windows stores configuration in user environment variables. macOS stores the URL under `$CODEX_HOME` and the key in macOS Keychain.

## Configuration

The helper resolves the relay base URL in this order:

1. `CODEX_IMAGE_RELAY_BASE_URL`.
2. `RELAY_BASE_URL`.
3. `$CODEX_HOME/api-image-base-url`, written by the macOS installer.
4. The active `base_url` in `$CODEX_HOME/config.toml`, including a selected provider section.

This allows an existing Codex custom provider configuration to call the relay directly without injecting the address on every run.

The relay API key is resolved from `CODEX_IMAGE_RELAY_API_KEY`, the macOS Keychain service `codex-api-image`, `OPENAI_API_KEY`, or the `OPENAI_API_KEY` field in `$CODEX_HOME/auth.json`. Never write the key into this skill or a shared file.

Optional:

- `CODEX_IMAGE_RELAY_MODEL`: default model. Defaults to `gpt-image-2.5-sunburst` for consistent final output.
- `CODEX_IMAGE_RELAY_OUTPUT_DIR`: output directory. Defaults to `$CODEX_HOME/generated_images/relay`.
- `CODEX_IMAGE_RELAY_TIMEOUT_MS`: request timeout. Defaults to 900000.

Company deployment may still prefer the dedicated environment variables when image traffic should use a different relay from the active Codex provider.

## Workflow

1. Decide whether the request is a new image or an edit.
2. Keep the model explicit. Use `CODEX_IMAGE_RELAY_MODEL` unless the user requests another supported model.
3. Run the helper directly:
   - Generate: `node scripts/image_relay.mjs generate --prompt "..."`
   - Edit: `node scripts/image_relay.mjs edit --input "C:\\path\\image.png" --prompt "..."`
4. Use `--size`, `--quality`, `--count`, and `--filename` when the user specifies them.
5. Read the JSON result, inspect the saved image with `view_image` when visual validation matters, and report the absolute path and model used.

Supported models are `gpt-image-2.5-sunburst`, `gpt-image-2.5-flare`, and `gpt-image-2`. The API is expected to be OpenAI-compatible:

- `POST /images/generations` with JSON.
- `POST /images/edits` with multipart form data.
- A JSON response containing `data[]` items with either `b64_json` or `url`.

The helper does not automatically retry paid generation requests by default. This avoids silently creating duplicate images and charges. If retries are needed, add them at the relay gateway with idempotency support rather than hiding them in the Skill.

Never print, echo, commit, or transmit the API key except as the HTTP authorization header required by the relay. Do not fall back to the built-in image generator or MCP when this Skill is selected; report configuration or relay errors clearly instead.
